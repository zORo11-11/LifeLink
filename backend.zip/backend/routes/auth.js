const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Donor = require('../models/Donor');
const { verifyToken, JWT_SECRET } = require('../middleware/auth');

// ==========================================
// 1. DONOR REGISTRATION
// ==========================================
router.post('/register', async (req, res) => {
  try {
    const { fullName, email, password, age, phone, address, bloodGroup, allergies, condition } = req.body;

    if (!email || !password || !fullName || !bloodGroup) {
      return res.status(400).json({ 
        success: false, 
        message: 'Full name, email, password, and blood group are required.' 
      });
    }

    // Check if donor already exists
    const existingDonor = await Donor.findOne({ email: email.toLowerCase().trim() });
    if (existingDonor) {
      return res.status(400).json({ 
        success: false, 
        message: 'Email is already registered' 
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Sanitized document creation
    const newDonor = new Donor({
      fullName: fullName.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      age: Number(age) || 18,
      phone: phone ? phone.trim() : '',
      address: address ? address.trim() : '',
      bloodGroup,
      allergies: allergies || '',
      condition: condition || '',
      isAvailable: true,
      totalDonations: 0
    });

    await newDonor.save();

    // Generate JWT token
    const token = jwt.sign(
      { id: newDonor._id, role: 'donor', email: newDonor.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const donorData = {
      id: newDonor._id,
      _id: newDonor._id,
      name: newDonor.fullName,
      fullName: newDonor.fullName,
      email: newDonor.email,
      bloodType: newDonor.bloodGroup,
      bloodGroup: newDonor.bloodGroup,
      available: newDonor.isAvailable,
      isAvailable: newDonor.isAvailable,
      phone: newDonor.phone,
      address: newDonor.address,
      totalDonations: newDonor.totalDonations
    };

    res.status(201).json({ 
      success: true, 
      message: 'Donor registered successfully!',
      token,
      donor: donorData
    });

  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: error.message || 'Server error during registration' 
    });
  }
});

// ==========================================
// 2. DONOR LOGIN
// ==========================================
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.'
      });
    }

    const donor = await Donor.findOne({ email: email.toLowerCase().trim() });
    if (!donor) {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid email or password' 
      });
    }

    const isMatch = await bcrypt.compare(password, donor.password);
    if (!isMatch) {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid email or password' 
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: donor._id, role: 'donor', email: donor.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const donorData = {
      id: donor._id,
      _id: donor._id,
      name: donor.fullName,
      fullName: donor.fullName,
      email: donor.email,
      bloodType: donor.bloodGroup,
      bloodGroup: donor.bloodGroup,
      available: donor.isAvailable,
      isAvailable: donor.isAvailable,
      phone: donor.phone,
      lastDonated: donor.lastDonated ? new Date(donor.lastDonated).toISOString().split('T')[0] : '',
      address: donor.address,
      totalDonations: donor.totalDonations || 0
    };

    res.status(200).json({
      success: true,
      message: 'Login successful!',
      token,
      donor: donorData
    });

  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: error.message || 'Server error during login' 
    });
  }
});

// ==========================================
// 3. UPDATE DONOR PROFILE (Protected Route)
// ==========================================
router.patch('/profile/:id', verifyToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Ensure donors can only update their own profile
    if (req.user.role === 'donor' && req.user.id !== id) {
      return res.status(403).json({ success: false, message: 'Forbidden. Cannot modify another donor profile.' });
    }

    const { totalDonations, lastDonated, isAvailable, available, phone, address } = req.body;

    const updateData = {};
    if (totalDonations !== undefined) updateData.totalDonations = totalDonations;
    if (lastDonated !== undefined) {
      updateData.lastDonated = lastDonated;
      updateData.lastDonation = lastDonated;
    }
    if (isAvailable !== undefined) updateData.isAvailable = isAvailable;
    if (available !== undefined) updateData.isAvailable = available;
    if (phone) updateData.phone = phone;
    if (address) updateData.address = address;

    const updatedDonor = await Donor.findByIdAndUpdate(
      id,
      { $set: updateData },
      { new: true }
    );

    if (!updatedDonor) {
      return res.status(404).json({ success: false, message: 'Donor profile not found' });
    }

    res.status(200).json({
      success: true,
      message: 'Donor profile updated successfully',
      donor: updatedDonor,
      data: updatedDonor
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Server error updating profile'
    });
  }
});

// GET list of active/all donors (For Hospital Map verification)
router.get('/all', async (req, res) => {
  try {
    const donors = await Donor.find({}, '-password').sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: donors });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;