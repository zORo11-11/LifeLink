import React, { createContext, useContext, useEffect, useState } from 'react';
import { API_BASE_URL } from '../services/api';

const SocketContext = createContext(null);

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    let ioClient;
    try {
      const io = require('socket.io-client');
      ioClient = io(API_BASE_URL, {
        transports: ['websocket', 'polling'],
        reconnectionAttempts: 5,
        timeout: 10000
      });

      ioClient.on('connect', () => {
        console.log('⚡ Connected to LifeLink Real-Time Sockets:', ioClient.id);
      });

      setSocket(ioClient);
    } catch (e) {
      console.warn('Socket.IO Client load error:', e);
    }

    return () => {
      if (ioClient) {
        ioClient.disconnect();
      }
    };
  }, []);

  return (
    <SocketContext.Provider value={socket}>
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  return useContext(SocketContext);
};
